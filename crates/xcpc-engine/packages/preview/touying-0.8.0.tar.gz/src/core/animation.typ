#import "../utils.typ"
#import "waypoints.typ": from-wp, waypoint-kinds // needed to support alternatives repeat-last with waypoints
#import "tree.typ"
#import "subslides.typ": (
  _is-placement, _parse-subslide-indices, animate-placements,
  assert-no-negative-subslides, last-required-subslide,
)
#import "blocks.typ": (
  alert, speaker-note, touying-equation, touying-fn-wrapper-raw, touying-mitex,
  touying-raw, touying-reducer,
)


/// ------------------------------------------------
/// Animation functions via metadata markers
/// ------------------------------------------------

/// Wrapper for a function to make it can receive `self` as an argument.
/// It is useful when you want to use `self` to get current subslide index, like `uncover` and `only` functions.
///
/// Example: `#let alternatives = touying-fn-wrapper.with(utils.alternatives)`
///
/// - fn (function): The function that will be called like `(self: none, ..args) => { .. }`.
///
/// - last-subslide (int): The max subslide count for the slide. Used by functions like `uncover`, `only`, and `alternatives-match` to determine the total number of subslides needed.
///
/// - repetitions (function): The repetitions for the function. It is useful for functions like `alternatives` with `start: auto`.
///
///   It accepts a `(repetitions, args)` and should return a (nextrepetitions, extra-args).
///
/// - advances-flow (bool): Whether this wrapper takes up the slide's pause flow, so that a following `#pause` continues after its last subslide rather than after the current one — true for `item-by-item`, which stands in for a run of pauses, and false for wrappers like `uncover` and `only`, which only animate their own body.
///
/// -> content
#let touying-fn-wrapper(
  fn,
  last-subslide: none,
  repetitions: none,
  advances-flow: false,
  ..args,
) = [#metadata((
  kind: "touying-fn-wrapper",
  fn: fn,
  args: args,
  last-subslide: last-subslide,
  repetitions: repetitions,
  advances-flow: advances-flow,
))<touying-temporary-mark>]

/// Wrapper for a slide function to make it can receive `self` as an argument.
///
/// Notice: This function is necessary for the slide function to work in Touying.
///
/// Example:
///
/// ```typst
/// #let slide(..args) = touying-slide-wrapper(self => {
///   touying-slide(self: self, ..args)
/// })
/// ```
///
/// - fn (function): The function that will be called with an argument `self` like `self => { .. }`.
///
/// -> content
#let touying-slide-wrapper(fn) = block[#metadata((
  kind: "touying-slide-wrapper",
  fn: fn,
))<touying-temporary-mark>]
//wrapping in a block to allow user labels to attach


/// Display content only in handout mode. (not presentation)
/// Don't reserve space when hidden, content is completely not existing there.
///
/// Unlike `handout-only`/`presentation-only`'s old callback-based
/// implementation, `body` here is embedded directly (not wrapped in a
/// deferred `touying-fn-wrapper` call) — `self.handout` is a static,
/// per-compile value, so which mode is active can be decided once at
/// slide-splitting time. This is also what lets `body` contain its own
/// slide-breaking elements (a heading, `#pagebreak()`, `---`) and have them
/// behave exactly as if this wrapper weren't there, in whichever mode this
/// content is actually visible.
///
/// Example:
///
/// ```typst
/// #handout-only[This content is only visible in handout mode.]
/// ```
///
/// - body (content): The content to display in handout mode.
///
/// -> content
#let handout-only(body) = [#metadata((
  kind: "touying-slides-only",
  body: body,
  visible-in: "handout",
))<touying-temporary-mark>]

/// Display content only in presentation mode. (not handout)
/// Don't reserve space when hidden, content is completely not existing there.
///
/// See `handout-only`'s docs for why `body` is embedded directly and can
/// itself contain slide-breaking elements.
///
/// Example:
///
/// ```typst
/// #presentation-only[This content is only visible in presentation mode.]
/// ```
///
/// - body (content): The content to display in presentation mode.
///
/// -> content
#let presentation-only(body) = [#metadata((
  kind: "touying-slides-only",
  body: body,
  visible-in: "presentation",
))<touying-temporary-mark>]



/// Content that only appears in handout or presentation (slides) mode.
///
/// In article mode this content is stripped entirely. Use this for
/// visual-only elements that don't make sense in a prose document
/// (e.g., decorative graphics, audience prompts, transition animations).
///
/// `body` may itself contain slide-breaking elements (a heading,
/// `#pagebreak()`, a bare `---`) — they behave exactly as if this wrapper
/// weren't there when in slides mode, and are simply never reached in
/// article mode since the whole wrapper is skipped there.
///
/// Example:
///
/// ```typst
/// #slides-only[
///   _Live demo here — see the code repository._
/// ]
/// ```
///
/// - body (content): The slides-only content.
///
/// -> content
#let slides-only(body) = [#metadata((
  kind: "touying-slides-only",
  body: body,
  visible-in: "slides",
))<touying-temporary-mark>]


/// Jump to a subslide position, either relatively or absolutely.
///
/// This is the unified core for both `#pause` and `#meanwhile`.
///
/// - When `relative: true` (relative mode): advances the subslide counter by `n`.
///   Positive `n` moves forward; negative `n` moves backward.
///   `n` must be a non-zero integer (zero would be a no-op with no visible effect).
///   `#pause` is equivalent to `#jump(1, relative: true)`.
///
/// - When `relative: false` (absolute mode, default): reveals all currently hidden
///   content and jumps to absolute subslide `n`.
///   `#meanwhile` is equivalent to `#jump(1)`.
///
/// Example:
///
/// ```typst
/// A #jump(1, relative: true) B   // same as A #pause B
/// A #jump(2, relative: true) C   // skip an extra subslide before C
/// A #pause B #jump(1) C          // C is always visible (same as #meanwhile)
/// A #pause B #jump(3) D          // D visible from subslide 3 onward
/// // A #pause B #pause C — normally C appears at subslide 3;
/// // adding #jump(-1, relative: true) before D makes D appear at subslide 2 (same as B):
/// A #pause B #pause C #jump(-1, relative: true) D
/// ```
///
/// - n (int): When `relative: true`, the number of subslides to advance (non-zero integer).
///   When `relative: false`, the absolute target subslide number (positive integer >= 1).
///
/// - relative (bool): If `true`, `n` is a relative offset from the current subslide counter.
///   If `false` (default), `n` is an absolute target subslide number.
///
/// -> content
#let jump(n, relative: false) = {
  if relative {
    assert(
      type(n) == int and n != 0,
      message: "jump: n must be a non-zero integer when relative: true, got "
        + repr(n),
    )
  } else {
    assert(
      type(n) == int and n >= 1,
      message: "jump: n must be a positive integer when relative: false, got "
        + repr(n),
    )
  }
  [#metadata((
    kind: "touying-jump/pause/meanwhile",
    n: n,
    relative: relative,
  ))<touying-temporary-mark>]
}


/// Reveal the next subslide. Inserts a subslide break: content after `#pause` appears one subslide later. Equivalent to `#jump(1, relative: true)`.
///
/// -> content
#let pause = jump(1, relative: true)


/// Reset the subslide counter back to 1, allowing content after `#meanwhile` to appear simultaneously with content from subslide 1. Equivalent to `#jump(1)`.
///
/// -> content
#let meanwhile = jump(1)


// Helper: check if a subslide spec string contains "h" (here marker)
// that needs deferred resolution to the current repetitions counter.
#let _has-here-marker(visible-subslides) = (
  type(visible-subslides) == str and visible-subslides.contains("h")
)

// Helper: create a last-subslide callback that resolves "h" in a string
// to the current repetitions counter at placement time.
#let _here-last-subslide(visible-subslides) = {
  repetitions => {
    let resolved = visible-subslides.replace("h", str(repetitions))
    (last-required-subslide(resolved), (resolved-subslides: resolved))
  }
}


/// Take effect in some subslides.
///
/// Example: `#effect(text.with(fill: red), "2-")[Something]` will display `[Something]` if the current slide is 2 or later.
///
/// You can also add an abbreviation by using `#let effect-red = effect.with(text.with(fill: red))` for your own effects.
///
/// - fn (function): The function that will be called in the subslide.
///      Or you can use a method function like `(self: none) => { .. }`.
///
/// - visible-subslides (int, array, str, label, dictionary): Specifies when content is visible.
///
///    Supported formats:
///
///    - A single integer, e.g. `3` — only subslide 3.
///    - An array, e.g. `(1, 2, 4)` — equivalent to `"1, 2, 4"`.
///    - A string with ranges, e.g. `"-2, 4, 6-8, 10-"` — subslides 1, 2, 4, 6, 7, 8, 10, and all after 10.
///    - A label, e.g. `<my-waypoint>` — shows from that waypoint's start until the next waypoint. creates a new implicit waypoint if it does not already exist.
///    - A waypoint marker, e.g. `from-wp(<label>)`, `until-wp(<label>)`, `get-first(<label>)`, etc.
///
/// - cont (content): The content to display when visible.
///
/// - is-method (bool): Whether the function is a method function. Default is `false`.
#let effect(fn, visible-subslides, cont, is-method: false) = {
  assert-no-negative-subslides("effect", visible-subslides)
  if visible-subslides == auto {
    // auto: resolve to current repetitions at placement time, no advance.
    touying-fn-wrapper(
      utils.effect,
      last-subslide: repetitions => (
        repetitions,
        (resolved-subslides: repetitions),
      ),
      fn,
      auto,
      is-method: is-method,
      cont,
    )
  } else if _has-here-marker(visible-subslides) {
    // "h" marker: deferred resolution of "h" to current repetitions.
    touying-fn-wrapper(
      utils.effect,
      last-subslide: _here-last-subslide(visible-subslides),
      fn,
      visible-subslides,
      is-method: is-method,
      cont,
    )
  } else {
    if type(visible-subslides) == label {
      [#metadata((
        kind: "touying-implicit-waypoint",
        label: str(visible-subslides),
      ))<touying-temporary-mark>]
    }
    touying-fn-wrapper(
      utils.effect,
      last-subslide: last-required-subslide(visible-subslides),
      fn,
      visible-subslides,
      is-method: is-method,
      cont,
    )
  }
}


/// Uncover content in some subslides. Reserved space when hidden (like `#hide()`).
///
/// #example(
/// >>> #let is-dark = sys.inputs.at("x-color-theme", default: none) == "dark";
/// >>> #let text-color = if is-dark { std.white } else { std.black };
/// >>> #show: simple-theme.with(
/// >>>   aspect-ratio: "16-9",
/// >>>   config-page(width: 320pt, height: 180pt),
/// >>>   config-colors(neutral-lightest: none, neutral-darkest: text-color),
/// >>> )
/// >>> #set text(.5em)
/// <<< #show: simple-theme.with(aspect-ratio: "16-9")
/// = Slide
///
/// #uncover("2-")[Only visible from subslide 2]
/// )
///
/// - visible-subslides (int, array, str, label, dictionary): Specifies when content is visible.
///
///    Supported formats:
///
///    - A single integer, e.g. `3` — only subslide 3.
///    - An array, e.g. `(1, 2, 4)` — equivalent to `"1, 2, 4"`.
///    - A string with ranges, e.g. `"-2, 4, 6-8, 10-"` — subslides 1, 2, 4, 6, 7, 8, 10, and all after 10.
///    - A label, e.g. `<my-waypoint>` — shows from that waypoint's start until the next waypoint. creates a new implicit waypoint if it does not already exist.
///    - A waypoint marker, e.g. `from-wp(<label>)`, `until-wp(<label>)`, `get-first(<label>)`, etc.
///
/// - uncover-cont (content): The content to display when visible.
///
/// - cover-fn (function, auto): An optional cover function to use instead of the default cover method from the theme. Useful when using `uncover` inside external package integrations (e.g. `fletcher.hide` for fletcher diagrams).
///
/// -> content
#let uncover(visible-subslides, uncover-cont, cover-fn: auto) = {
  assert-no-negative-subslides("uncover", visible-subslides)
  if visible-subslides == auto {
    // auto: resolve to current repetitions at placement time, no advance.
    touying-fn-wrapper(
      utils.uncover,
      last-subslide: repetitions => (
        repetitions,
        (resolved-subslides: repetitions),
      ),
      auto,
      uncover-cont,
      cover-fn: cover-fn,
    )
  } else if _has-here-marker(visible-subslides) {
    // "h" marker: deferred resolution of "h" to current repetitions.
    touying-fn-wrapper(
      utils.uncover,
      last-subslide: _here-last-subslide(visible-subslides),
      visible-subslides,
      uncover-cont,
      cover-fn: cover-fn,
    )
  } else {
    if type(visible-subslides) == label {
      [#metadata((
        kind: "touying-implicit-waypoint",
        label: str(visible-subslides),
      ))<touying-temporary-mark>]
    }
    touying-fn-wrapper(
      utils.uncover,
      last-subslide: last-required-subslide(visible-subslides),
      visible-subslides,
      uncover-cont,
      cover-fn: cover-fn,
    )
  }
}


/// Display content in some subslides only. No space is reserved when hidden.
///
/// #example(
/// >>> #let is-dark = sys.inputs.at("x-color-theme", default: none) == "dark";
/// >>> #let text-color = if is-dark { std.white } else { std.black };
/// >>> #show: simple-theme.with(
/// >>>   aspect-ratio: "16-9",
/// >>>   config-page(width: 320pt, height: 180pt),
/// >>>   config-colors(neutral-lightest: none, neutral-darkest: text-color),
/// >>> )
/// >>> #set text(.5em)
/// <<< #show: simple-theme.with(aspect-ratio: "16-9")
/// = Slide
///
/// #only("2")[Only on subslide 2]
/// )
///
/// - visible-subslides (int, array, str, label, dictionary): Specifies when content is visible.
///
///    Supported formats:
///
///    - A single integer, e.g. `3` — only subslide 3.
///    - An array, e.g. `(1, 2, 4)` — equivalent to `"1, 2, 4"`.
///    - A string with ranges, e.g. `"-2, 4, 6-8, 10-"` — subslides 1, 2, 4, 6, 7, 8, 10, and all after 10.
///    - A label, e.g. `<my-waypoint>` — shows from that waypoint's start until the next waypoint. creates a new implicit waypoint if it does not already exist.
///    - A waypoint marker, e.g. `from-wp(<label>)`, `until-wp(<label>)`, `get-first(<label>)`, etc.
///
/// - only-cont (content): The content to display when visible.
///
/// -> content
#let only(visible-subslides, only-cont) = {
  assert-no-negative-subslides("only", visible-subslides)
  if visible-subslides == auto {
    // auto: resolve to current repetitions at placement time, no advance.
    touying-fn-wrapper(
      utils.only,
      last-subslide: repetitions => (
        repetitions,
        (resolved-subslides: repetitions),
      ),
      auto,
      only-cont,
    )
  } else if _has-here-marker(visible-subslides) {
    // "h" marker: deferred resolution of "h" to current repetitions.
    touying-fn-wrapper(
      utils.only,
      last-subslide: _here-last-subslide(visible-subslides),
      visible-subslides,
      only-cont,
    )
  } else {
    if type(visible-subslides) == label {
      [#metadata((
        kind: "touying-implicit-waypoint",
        label: str(visible-subslides),
      ))<touying-temporary-mark>]
    }
    touying-fn-wrapper(
      utils.only,
      last-subslide: last-required-subslide(visible-subslides),
      visible-subslides,
      only-cont,
    )
  }
}


/// `#alternatives` has a couple of "cousins" that might be more convenient in some situations. The first one is `#alternatives-match` that has a name inspired by match-statements in many functional programming languages. The idea is that you give it a dictionary mapping from subslides to content:
///
/// Example:
///
/// ```typst
/// #alternatives-match((
///   "1, 3-5": [this text has the majority],
///   "2, 6": [this is shown less often]
/// ))
/// ```
///
/// - subslides-contents (dictionary): A dictionary mapping from subslides to content.
///
/// - position (alignment): The alignment of alternatives within the reserved space. Default is `bottom + left`.
///
/// - stretch (bool): Whether to stretch all alternatives to the maximum width and height. Default is `false`.
///
///   Important: If you use a zero-length content like a context expression, you should set `stretch: false`.
///
/// -> content
#let alternatives-match(
  subslides-contents,
  position: bottom + left,
  stretch: false,
) = {
  // Validate: alternatives-match doesn't support waypoints, only numeric subslide specs
  let keys = if type(subslides-contents) == dictionary {
    subslides-contents.keys()
  } else {
    subslides-contents.map(kv => kv.at(0))
  }
  for key in keys {
    assert-no-negative-subslides("alternatives-match", key)
    if type(key) == label {
      panic(
        "alternatives-match: waypoint labels are not supported. Use alternatives() with the at: parameter instead.",
      )
    }
    if (
      type(key) == dictionary
        and "kind" in key
        and str(key.kind) in waypoint-kinds
    ) {
      panic(
        "alternatives-match: waypoint markers are not supported. Use alternatives() with the at: parameter instead.",
      )
    }
  }
  touying-fn-wrapper(
    utils.alternatives-match,
    last-subslide: if type(subslides-contents) == dictionary {
      calc.max(..subslides-contents
        .pairs()
        .map(kv => last-required-subslide(kv.at(0))))
    } else {
      calc.max(..subslides-contents.map(kv => last-required-subslide(
        kv.at(0),
      )))
    },
    subslides-contents,
    position: position,
    stretch: stretch,
  )
}


/// `#alternatives` is able to show contents sequentially in subslides.
///
/// Example: `#alternatives[Ann][Bob][Christopher]` will show "Ann" in the first subslide, "Bob" in the second subslide, and "Christopher" in the third subslide.
///
/// You can also use waypoint labels via the `at` parameter:
///
/// ```typst
/// #alternatives(at: (<first>, <second>))[Content A][Content B]
/// ```
///
/// - start (int): The starting subslide number. Default is `auto`.
///
/// - repeat-last (bool): Whether the last alternative should persist on all remaining subslides. Default is `true`.
///
/// - position (alignment): The alignment of alternatives within the reserved space. Default is `bottom + left`.
///
/// - stretch (bool): Whether to stretch all alternatives to the maximum width and height. Default is `false`.
///
///   Important: If you use a zero-length content like a context expression, you should set `stretch: false`.
///
/// - at (none | array): An array of waypoint labels (or waypoint markers like `get-first(<label>)`) or subslide specs, one per body.
///   When provided, each body is mapped to the corresponding waypoint range.
///   This is an alternative to the sequential `start`-based numbering.
///
/// -> content
#let alternatives(
  start: auto,
  repeat-last: true,
  position: bottom + left,
  stretch: false,
  at: none,
  ..args,
) = {
  // no need to assert for `at` since it only allows waypoints.
  assert-no-negative-subslides("alternatives: `start`", start)
  if at != none {
    // Waypoint-based alternatives: map each label to its corresponding body
    let bodies = args.pos()
    assert(
      at.len() == bodies.len(),
      message: "alternatives: `at` array length ("
        + str(at.len())
        + ") must match number of bodies ("
        + str(bodies.len())
        + ")",
    )
    let subslides = at
    if repeat-last and subslides.len() > 0 {
      // Replace last entry with a from-wp() marker so it shows from that
      // waypoint onward (not just within its bounded range).
      let last-entry = subslides.last()
      subslides.at(-1) = if type(last-entry) == label {
        from-wp(last-entry)
      } else {
        last-entry
      }
    }
    let subslides-contents = subslides.zip(bodies)
    touying-fn-wrapper(
      utils.alternatives-match,
      last-subslide: calc.max(
        ..subslides.map(s => last-required-subslide(s)),
      ),
      subslides-contents,
      position: position,
      stretch: stretch,
    )
  } else {
    let extra = if start == auto {
      (
        last-subslide: repetitions => (
          repetitions + args.pos().len() - 1,
          (start: repetitions),
        ),
      )
    } else {
      (
        last-subslide: start + args.pos().len() - 1,
      )
    }
    touying-fn-wrapper(
      utils.alternatives,
      start: start,
      repeat-last: repeat-last,
      position: position,
      stretch: stretch,
      ..extra,
      ..args,
    )
  }
}


/// You can have very fine-grained control over the content depending on the current subslide by using `#alternatives-fn`. It accepts a function (hence the name) that maps the current subslide index to some content.
///
/// Example: `#alternatives-fn(start: 2, count: 7, subslide => { numbering("(i)", subslide) })`
///
/// - start (int): The starting subslide number. Default is `1`.
///
/// - end (none, int): The ending subslide number. Default is `none`.
///
/// - count (none, int): The number of subslides. Default is `none`.
///
/// - position (alignment): The alignment of alternatives within the reserved space. Default is `bottom + left`.
///
/// - stretch (bool): Whether to stretch all alternatives to the maximum width and height. Default is `false`.
///
///   Important: If you use a zero-length content like a context expression, you should set `stretch: false`.
///
/// -> content
#let alternatives-fn(
  start: 1,
  end: none,
  count: none,
  position: bottom + left,
  stretch: false,
  ..kwargs,
  fn,
) = {
  // Validate integer parameters
  assert(
    type(start) == int,
    message: "alternatives-fn: start must be an integer, got "
      + str(type(start)),
  )
  if end != none {
    assert(
      type(end) == int,
      message: "alternatives-fn: end must be an integer or none, got "
        + str(type(end)),
    )
  }
  if count != none {
    assert(
      type(count) == int,
      message: "alternatives-fn: count must be an integer or none, got "
        + str(type(count)),
    )
  }
  let end = if end == none {
    if count == none {
      panic("You must specify either end or count.")
    } else {
      start + count
    }
  } else {
    end
  }
  touying-fn-wrapper(
    utils.alternatives-fn,
    last-subslide: end,
    start: start,
    end: end,
    count: count,
    position: position,
    stretch: stretch,
    ..kwargs,
    fn,
  )
}


/// You can use this function if you want to have one piece of content that changes only slightly depending of what "case" of subslides you are in.
///
/// Example:
///
/// ```typst
/// #alternatives-cases(("1, 3", "2"), case => [
///   #set text(fill: teal) if case == 1
///   Some text
/// ])
/// ```
///
/// - cases (array): An array of strings that specify the subslides for each case.
///
/// - fn (function): A function that maps the case to content. The argument `case` is the index of the cases array you input.
///
/// - position (alignment): The alignment of alternatives within the reserved space. Default is `bottom + left`.
///
/// - stretch (bool): Whether to stretch all alternatives to the maximum width and height. Default is `false`.
///
///   Important: If you use a zero-length content like a context expression, you should set `stretch: false`.
///
/// -> content
#let alternatives-cases(
  cases,
  fn,
  position: bottom + left,
  stretch: false,
  ..kwargs,
) = {
  // Validate: alternatives-cases doesn't support waypoints, only numeric subslide specs
  for case in cases {
    assert-no-negative-subslides("alternatives-cases", case)
    if type(case) == label {
      panic(
        "alternatives-cases: waypoint labels are not supported. Use alternatives() with the at: parameter instead.",
      )
    }
    if (
      type(case) == dictionary
        and "kind" in case
        and str(case.kind) in waypoint-kinds
    ) {
      panic(
        "alternatives-cases: waypoint markers are not supported. Use alternatives() with the at: parameter instead.",
      )
    }
  }
  touying-fn-wrapper(
    utils.alternatives-cases,
    last-subslide: calc.max(..cases.map(last-required-subslide)),
    cases,
    fn,
    position: position,
    stretch: stretch,
    ..kwargs,
  )
}


/// Display list, enum, or terms items one by one with animation.
///
/// Each item is revealed on a successive subslide.  By default (`start: auto`),
/// revealing is relative to the current pause position — items appear one per
/// subslide starting from wherever the slide's animation has reached.
///
/// `start` also accepts a waypoint label (e.g. `<my-wp>`) or any waypoint
/// marker (`from-wp(<wp>)`, `get-first(<wp>)`, etc.) to anchor the reveal
/// sequence to a named position.
///
/// == Examples
///
/// ```typst
/// // Relative (auto) — items appear after any preceding #pause
/// #item-by-item[
///   - first
///   - second
///   - third
/// ]
///
/// // Anchored to a waypoint
/// #waypoint(<items>)
/// #item-by-item(start: <items>)[
///   - alpha
///   - beta
/// ]
///
/// // Explicit absolute subslide number (backward compatible)
/// #item-by-item(start: 3)[
///   - x
///   - y
/// ]
/// ```
///
/// - start (auto | int | label | dictionary): The subslide on which the first
///   item appears.  `auto` (default) makes it relative to the current pause
///   position.  An integer gives an absolute subslide number.  A label or
///   waypoint marker resolves to the waypoint's first subslide.
///
/// - cont (content): The content containing a list, enum, or terms element.
///
/// -> content
#let item-by-item(start: auto, cont) = {
  assert-no-negative-subslides("item-by-item: `start`", start)
  if (
    type(start) == dictionary
      and start.at("kind", default: none)
        in ("touying-waypoint-from", "touying-waypoint-until")
  ) {
    panic(
      "item-by-item: `start` must resolve to a single subslide position. "
        + "`from-wp` and `until-wp` are range markers and are not supported here. "
        + "Use a label, `get-first`, `get-last`, `prev-wp`, `next-wp` or simple slide numbers instead.",
    )
  }
  let num-items = tree.count-items(cont)
  if start == auto {
    // Relative: items start from the current pause position.
    touying-fn-wrapper(
      utils.item-by-item,
      advances-flow: true,
      last-subslide: repetitions => (
        repetitions + num-items - 1,
        (start: repetitions),
      ),
      start: start,
      cont,
    )
  } else if type(start) == int {
    touying-fn-wrapper(
      utils.item-by-item,
      advances-flow: true,
      last-subslide: start + num-items - 1,
      start: start,
      cont,
    )
  } else if type(start) == str {
    let parts = _parse-subslide-indices(start)
    if parts.len() != 1 or type(parts.first()) != int {
      panic(
        "item-by-item: `start` string must be a single number (e.g. \"3\"), "
          + "not a range or multi-value spec. Got: \""
          + start
          + "\".",
      )
    }
    let n = parts.first()
    touying-fn-wrapper(
      utils.item-by-item,
      advances-flow: true,
      last-subslide: n + num-items - 1,
      start: n,
      cont,
    )
  } else {
    // Label or waypoint marker — resolved at render time.
    // For a plain label, emit an implicit waypoint so users don't need to write
    // a separate #waypoint(<label>) before the call.  The _waypoint-known check
    // in the prepass ensures the waypoint is only registered once even if an
    // explicit #waypoint(<label>) is also present.
    // Dictionary markers (from-wp, next-wp, get-first, …) reference an existing
    // explicit waypoint, so no implicit waypoint is needed for those.
    if type(start) == label {
      [#metadata((
        kind: "touying-implicit-waypoint",
        label: str(start),
      ))<touying-temporary-mark>]
    }
    // At callback time, `repetitions` equals the waypoint's subslide number
    // (the implicit or explicit waypoint was processed just before this wrapper).
    // We need num-items subslides starting from there, so the last subslide
    // needed is repetitions + num-items - 1.
    // Return empty extra-args so the original label/marker `start` is preserved
    // for render-time resolution via resolve-waypoints.
    touying-fn-wrapper(
      utils.item-by-item,
      advances-flow: true,
      last-subslide: repetitions => (
        repetitions + num-items - 1,
        (:),
      ),
      start: start,
      cont,
    )
  }
}

/// Makes the currently revealed item bold. You may pass it an optional `weight` parameter. See https://typst.app/docs/reference/text/text/#parameters-weight. Default is `"bold"`.
///
/// - time (int): The relative subslide index passed by item-by-item-fn.
/// - it (content): The item passed by item-by-item-fn.
/// - weight (str): The weight of the bold text. Default is `"bold"`.
/// -> content
#let current-bold(time, it, weight: "bold") = {
  if time == 0 {
    text(weight: weight, it)
  } else {
    it
  }
}
/// Highlights the currently revealed item with a yellow background. You may give it an optional `style` parameter (dictionary) to customize the highlight style. See https://typst.app/docs/reference/text/highlight/.
///
/// - time (int): The relative subslide index passed by item-by-item-fn.
/// - it (content): The item passed by item-by-item-fn.
/// - style (dictionary): The style parameters for the highlight.
/// -> content
#let current-highlight(time, it, style: (fill: rgb("#fffd11a1"))) = {
  if time == 0 {
    highlight(..style, it)
  } else {
    it
  }
}
/// Fades already revealed items by reducing their fill alpha. You may pass it an optional `alpha` parameter, default is `20%`.
///
/// - time (int): The relative subslide index passed by item-by-item-fn.
/// - it (content): The item passed by item-by-item-fn.
/// - alpha (float): The alpha value for the fade effect. Default is `20%`.
/// -> content
#let past-faded(time, it, alpha: 20%) = context {
  if time < 0 {
    text(fill: utils.update-alpha(text.fill, alpha), it)
  } else {
    it
  }
}
/// Fades already revealed items with a progressive fade. You may pass it an optional `alpha` dict. Possible keys are `linear` and `exponential` for linear and exponential fading, respectively. The value is the fading speed. Default is `(linear: 30%)`.
///
/// - time (int): The relative subslide index passed by item-by-item-fn.
/// - it (content): The item passed by item-by-item-fn.
/// - alpha (dictionary): The fade speed and type, higher means faster fading. Either `(linear: <value>)` or `(exponential: <value>)`.  Default is `(linear: 30%)`.
/// -> content
#let past-progressive-faded(time, it, alpha: (linear: 30%)) = context {
  assert(
    type(alpha) == dictionary
      and alpha.keys().len() == 1
      and alpha.keys().first() in ("linear", "exponential"),
    message: "Invalid alpha spec for past-progressive-faded. Expected {linear: <value>} or {exponential: <value>}, got "
      + repr(alpha),
  )

  let fade = if "linear" in alpha.keys() {
    calc.clamp(1 + time * float(alpha.linear), 0, 1)
  } else {
    // exponential
    calc.clamp(calc.pow(1 - float(alpha.exponential), -time), 0, 1)
  }
  text(fill: utils.update-alpha(text.fill, fade * 100%), it)
}
/// Styling presets for item-by-item-fn. Available ones are:
/// - `current-bold`: Makes the currently revealed item bold. You may pass it an optional `weight` parameter. See https://typst.app/docs/reference/text/text/#parameters-weight. Default is `"bold"`.
/// - `current-highlight`: Highlights the currently revealed item with a yellow background. You may give it an optional `style` parameter (dictionary) to customize the highlight style. See https://typst.app/docs/reference/text/highlight/.
/// - `past-faded`: Fades already revealed items by reducing their fill alpha. You may pass it an optional `alpha` parameter, default is `20%`.
/// - `past-progressive-faded`: Fades already revealed items with a progressive fade. You may pass it an optional `alpha` dict. Possible keys are `linear` and `exponential` for linear and exponential fading, respectively. The value is the fading speed. Default is `(linear: 30%)`.
/// See the respective functions for more details.
///
/// Usage:\
/// `#item-by-item-fn("current-highlight")[ ... ]` \
/// or if you want to customize the style: \
/// `#item-by-item-fn(item-by-item-functions.at("current-highlight").with(style: (stroke: red)))[ ... ]` or \
/// `#item-by-item-fn((item-by-item-functions.current-highlight).with(style: (stroke: red)))[ ... ]`
#let item-by-item-functions = (
  current-bold: current-bold,
  current-highlight: current-highlight,
  past-faded: past-faded,
  past-progressive-faded: past-progressive-faded,
)

/// Display list, enum, or terms items one by one with animation and styling.
/// For basic details, see `#item-by-item`, this is a more customizable version that accepts a styling function to style each item depending on whether it's being revealed, already revealed, or still hidden.
///
/// - start (auto | int | label | dictionary): The subslide on which the first
///   item appears.  `auto` (default) makes it relative to the current pause
///   position.  An integer gives an absolute subslide number.  A label or
///   waypoint marker resolves to the waypoint's first subslide.
///
/// - fn (function, str): A styling function that styles each item. It receives `(time (int), it)` where `time` is the relative subslide index, i.e. it may be negative, 0 or positive depending on whether the item was revealed, is being revealed or will be revealed in the future. If none, this defaults to the normal `item-by-item` behavior of simply revealing items without additional styling. Note that this does not interfere with the normal cover mechanism. \ We support several presets for this: `"current-bold"`, `"current-highlight"`, `"past-faded"`, `"past-progressive-faded"` available either by passing in these strings or in the dictionary `item-by-item-functions`. The latter let's you customize the presets.
///
/// - cont (content): The content containing a list, enum, or terms element.
///
/// -> content
#let item-by-item-fn(start: auto, fn, cont) = {
  assert-no-negative-subslides("item-by-item-fn: `start`", start)
  if type(fn) == str {
    assert(
      fn in item-by-item-functions.keys(),
      message: "Unknown preset for item-by-item-fn: "
        + repr(fn)
        + ". Available presets are: "
        + repr(item-by-item-functions.keys()),
    )
    fn = item-by-item-functions.at(fn)
  }
  assert(
    type(fn) in (function, type(none)),
    message: "item-by-item-fn: `fn` must be a function or a preset name string, got "
      + repr(type(fn)),
  )

  if (
    type(start) == dictionary
      and start.at("kind", default: none)
        in ("touying-waypoint-from", "touying-waypoint-until")
  ) {
    panic(
      "item-by-item-fn: `start` must resolve to a single subslide position. "
        + "`from-wp` and `until-wp` are range markers and are not supported here. "
        + "Use a label, `get-first`, `get-last`, `prev-wp`, `next-wp` or simple slide numbers instead.",
    )
  }
  let num-items = tree.count-items(cont)
  if start == auto {
    touying-fn-wrapper(
      utils.item-by-item-fn,
      advances-flow: true,
      last-subslide: repetitions => (
        repetitions + num-items - 1,
        (start: repetitions),
      ),
      start: start,
      fn,
      cont,
    )
  } else if type(start) == int {
    touying-fn-wrapper(
      utils.item-by-item-fn,
      advances-flow: true,
      last-subslide: start + num-items - 1,
      start: start,
      fn,
      cont,
    )
  } else if type(start) == str {
    let parts = _parse-subslide-indices(start)
    if parts.len() != 1 or type(parts.first()) != int {
      panic(
        "item-by-item-fn: `start` string must be a single number (e.g. \"3\"), "
          + "not a range or multi-value spec. Got: \""
          + start
          + "\".",
      )
    }
    let n = parts.first()
    touying-fn-wrapper(
      utils.item-by-item-fn,
      advances-flow: true,
      last-subslide: n + num-items - 1,
      start: n,
      fn,
      cont,
    )
  } else {
    if type(start) == label {
      [#metadata((
        kind: "touying-implicit-waypoint",
        label: str(start),
      ))<touying-temporary-mark>]
    }
    touying-fn-wrapper(
      utils.item-by-item-fn,
      advances-flow: true,
      last-subslide: repetitions => (
        repetitions + num-items - 1,
        (:),
      ),
      start: start,
      fn,
      cont,
    )
  }
}

/// Render a content block at a specific animation stage, or step through
/// several of them. Unlike `touying-recall` (./src/core/slides.typ), which
/// looks up content by label that has already been rendered once,
/// this takes a content variable directly.
///
/// Example:
///
/// ```typ
/// #let ccanvas = touying-reducer(label: "doc-test-diagram", reduce: cetz.canvas, ...)
/// #ccanvas
///
/// #article-text[
///   Stage 2 of the canvas:
///   #touying-render(ccanvas, subslides: 2)
/// ]
/// ```
///
/// - body (content): The content to render. Can be a reducer metadata node
///   or any arbitrary content containing animation primitives.
///
/// - subslides (auto, int, str, label, dictionary): Which animation
///   stage(s) of `body` to show — its own local numbering, unaffected by
///   where in the enclosing slide this call sits.
///   - `auto` (default): tracks the enclosing slide's own subslide
///     progression directly, uncapped — a self-advancing miniature preview
///     of `body`, e.g. for a slide-thumbnail overview. `start`/
///     `repeat-last` still apply (see below): given an explicit `start`,
///     this instead steps through `body`'s *entire* natural range one
///     stage per outer subslide — the same stepping every other,
///     non-`auto` spec below gets, just implicitly spanning all of `body`
///     rather than an explicit subset of it.
///   - `int`: a specific 1-indexed subslide number (negative indices count
///     from the end) — a single, frozen stage.
///   - `str`: a range spec in the same syntax as `uncover`/`only`
///     (`"2-4"`, `"-2, 6-"`, `"!2-4"`) — every subslide it matches becomes
///     one exposed member (see stepping below); a spec matching only one
///     subslide (e.g. `"3"`) behaves exactly like the plain `int` case.
///      `"h"` resolves to this render's own numbering
///     anchor (`base`, or the outer slide's current position when
///     `base: auto`)
///   - `label`/waypoint marker (`get-first(<wp>)`, `get-last(<wp>)`,
///     `from-wp`, `until-wp`, `not-wp`, ...): a single-point marker
///     (`get-first`, `get-last`) exposes one frozen stage; a bare label or
///     a range/complement marker (`from-wp`, `until-wp`, `not-wp`) exposes
///     every subslide it spans — `not-wp`'s gap is simply skipped over,
///     collapsing onto whichever member comes right after it.
///
///   A waypoint marker names one of `body`'s own waypoints, the same way it
///   does for `touying-recall`. Set `use-outer-waypoints` to aim it at the
///   enclosing slide's waypoints instead.
///
/// - base (auto, int): Starting repetition counter for `body`'s own
///   internal pause-numbering — purely internal to `body`, never affects
///   the enclosing slide's own numbering (see `start` for that).
///   Use this to align absolute with relative animations that you render.
///   - `auto` (default): in slide mode, starts at the enclosing slide's
///     repetition counter as it stands where this call sits; in article
///     mode, resolves to `1`.
///   - `int`: explicit offset, e.g. `base: 3` makes the first pause
///     create subslide 4 instead of 2.
///
/// - start (auto, int, label, dictionary): Where, in the *enclosing*
///   slide's own subslide numbering, `body`'s exposed member(s) begin
///   stepping. `auto` (default) starts at the outer slide's very first subslide — except
///   for `subslides: auto` specifically, where it's instead a strict
///   no-op: `body` is always visible, tracking the enclosing slide's raw
///   current subslide with no capping (today's original behavior,
///   unchanged). Given an explicit `start`, `body`'s exposed member(s) are
///   absent entirely (like `only`, not `uncover` — no reserved layout
///   space) until the enclosing slide reaches it, then visible from then
///   on — see `repeat-last` for what happens once they run out. Has no
///   effect in article mode (warns if given a non-default value there).
///
/// - repeat-last (bool): What happens once `body`'s exposed member(s) are
///   exhausted (only relevant together with an explicit `start`).
///   - `true` (default): hold at the final member forever after — matches
///     `alternatives`' own default.
///   - `false`: remove `body` again (no reserved layout space) once past
///     its own natural duration, instead of freezing on the last member.
///
/// - use-outer-waypoints (bool): Resolve a waypoint marker in `subslides`
///   against the enclosing slide's waypoints instead of `body`'s own, to aim
///   at a position named outside. Needs `base: auto`, an explicit `base`
///   makes `body` its own timeline. Default is `false`.
///
/// -> content
#let touying-render(
  body,
  subslides: auto,
  base: auto,
  start: auto,
  repeat-last: true,
  use-outer-waypoints: false,
) = {
  [#metadata((
    kind: "touying-render",
    content: body,
    subslides: subslides,
    base: base,
    start: start,
    repeat-last: repeat-last,
    use-outer-waypoints: use-outer-waypoints,
  ))<touying-temporary-mark>]
}

/// Replace `body` with `swap-body` while this effect is active. Only for use
/// as an `#animate` effect.
///
/// - swap-body (content): What to render in `body`'s place.
///
/// - alignment (alignment): Where `swap-body` sits inside the reserved space.
///
/// - stretch (bool): Whether `swap-body` joins the reserved space, exactly as
///   in `alternatives`. Default is `false`, which lets the layout reflow when
///   this swap is shown. With `true` it is measured along with everything else
///   that reserves, so the block keeps one size across every subslide.
///
///   Important: If you use a zero-length content like a context expression,
///   you should set `stretch: false`.
///
/// -> dictionary
#let swap(swap-body, alignment: top + left, stretch: false) = (
  kind: "touying-swap",
  body: swap-body,
  alignment: alignment,
  stretch: stretch,
)

/// Animate content arbitrarily with your own or builtin effects.
/// Use this for special cases where you want to combine visibility, effects, ...
/// Effects may be layered arbitrarily.
///
/// Example:
///
/// ```typst
/// #animate(
///   [The original],
///   effects: (
///     (effect: "cover", subslides: "-2"),
///     (effect: swap[Something else], subslides: 3),
///     (effect: (body, ..) => text(red, body), subslides: "4-", priority: 2),
///   ),
/// )
/// ```
///
/// == Placement versus styling
///
/// Effects fall into two classes, and they combine differently.
///
/// *Placements* — `"show"`, `"cover"`, `"remove"` and `swap(..)` — decide
/// whether and in what form `body` appears at all. Exactly one of them applies
/// per subslide, see priority below.
///
/// *Styles* — any function you pass — all apply, nested inside one another,
/// because that is something Typst composes correctly on its own.
///
/// == Priority
///
/// An effect of type `"show"` with subslides `"1-"` and priority `0` is
/// applied by default, and your own effects default to priority `1`, so
/// writing any placement at all replaces it. Among the placements active on a
/// subslide the highest priority wins, ties going to the last one written. For
/// styles priority only sets the nesting order: lowest is innermost, and
/// within one priority the last one written is innermost, so it wins any
/// property both of them set.
///
/// Ties therefore break the same way in both classes — the last effect you
/// wrote wins — a placement by being the one used, a style by ending up
/// innermost.
///
/// `animate-hidden` and `animate-removed` are this function with a `"cover"`
/// or `"remove"` placement already in front of your effects at priority 0, so
/// anything you write still takes precedence over it.
///
/// == Space
///
/// `"cover"` reserves `body`'s space entirely and `"remove"` reserves none at
/// all, exactly as `uncover` and `only` do. A `swap` replaces `body` outright,
/// just like `alternatives`, and reflows the layout while it is shown —
/// unless it is given `stretch: true`, which puts it into the reserved space
/// along with `body` itself, so that the block keeps one size throughout.
///
/// Nothing is measured unless at least one swap asks to stretch. When one
/// does, the reserved space is the overlay of everything that actually renders
/// and reserves, measured *with* the styles that are active where it renders:
/// each distinct combination of placement and styles is measured once. As with
/// `alternatives`' `stretch`, zero-length content such as a bare `context`
/// expression cannot be measured usefully, provide a fixed-size box wrapping
/// it in that case.
///
/// - body (content): The entire content onto which the effects will apply.
///
/// - effects (array, dictionary): The effects, each a dictionary with the keys
///   below. A single effect may be given on its own instead of in an array.
///
///   - effect (function, str, dictionary): The builtin effects are `"cover"`,
///     `"remove"`, `"show"` and
///     `swap(body, alignment: top + left, stretch: false)`.
///     If passed a function it needs the following header:
///     `(body, self: none) -> content` \
///     From self you can extract the current subslide and waypoint.
///     To use a simple function like `text.with(red)` write `(body, ..args) => text(red, body)` instead.
///   - subslides (int, str, label, dictionary): Subslide types as usual (see docstring of `uncover`),
///     corresponding to integer subslides, string subslide ranges, waypoints or waypoint markers.
///     The effect will only be invoked if the current subslide is among the range given.
///     Defaults to `"1-"`.
///   - priority (int): Defaults to `1`. See above.
///
///   If you want to cover content via `utils.alpha-changing-cover` or
///   `utils.color-changing-cover`, you can use those functions directly as a
///   styling effect.
///
/// - alignment (alignment): Where `body` itself sits inside the reserved box,
///   when a swap makes one necessary. Each swap carries its own alignment.

///
/// -> content
#let animate(
  body,
  effects: (),
  alignment: top + left,
) = {
  // A single effect may be written without the enclosing array; `(:)` and `()`
  // both mean "no effects", i.e. plain `body`.
  let effects = if type(effects) == dictionary {
    if effects.len() == 0 { () } else { (effects,) }
  } else {
    effects
  }
  let effects = effects
    .enumerate()
    .map(((i, eff)) => {
      assert(
        type(eff) == dictionary and "effect" in eff,
        message: "animate: effects.at("
          + str(i)
          + ") must be a dictionary with "
          + "an `effect` key, got "
          + repr(eff),
      )
      let kind = eff.effect
      assert(
        type(kind) == function or _is-placement(kind),
        message: "animate: effects.at("
          + str(i)
          + ").effect must be a function, "
          + "a swap, or one of "
          + repr(animate-placements)
          + ", got "
          + repr(kind),
      )
      let subslides = eff.at("subslides", default: "1-")
      assert-no-negative-subslides(
        "animate: effects.at(" + str(i) + ").subslides",
        subslides,
      )
      assert(
        subslides != auto,
        message: "animate: effects.at("
          + str(i)
          + ").subslides does not support "
          + "`auto`; write \"h\" for this effect's own placement position, or an "
          + "explicit range.",
      )
      (
        effect: kind,
        subslides: subslides,
        priority: eff.at("priority", default: 1),
      )
    })
  // A label spec names a waypoint, which has to exist by the time the spec is
  // resolved — same implicit declaration `effect`/`uncover` make.
  for eff in effects {
    if type(eff.subslides) == label {
      [#metadata((
        kind: "touying-implicit-waypoint",
        label: str(eff.subslides),
      ))<touying-temporary-mark>]
    }
  }
  let last-of(specs) = calc.max(
    1,
    ..specs.map(last-required-subslide),
  )
  if effects.any(eff => _has-here-marker(eff.subslides)) {
    // At least one spec says "h", so every spec has to be resolved against the
    // repetitions counter at placement time rather than up front.
    touying-fn-wrapper(
      utils.animate,
      last-subslide: repetitions => {
        let resolved = effects.map(eff => if _has-here-marker(eff.subslides) {
          eff.subslides.replace("h", str(repetitions))
        } else {
          eff.subslides
        })
        (last-of(resolved), (resolved-subslides: resolved))
      },
      effects: effects,
      alignment: alignment,
      body,
    )
  } else {
    touying-fn-wrapper(
      utils.animate,
      last-subslide: last-of(effects.map(eff => eff.subslides)),
      effects: effects,
      alignment: alignment,
      body,
    )
  }
}


// Put `placement` in front of the caller's own effects as an ordinary
// priority-0 placement. It therefore beats `animate`'s implicit priority-0
// "show" (a tie, and this one is written later), while anything the caller
// writes still beats it — their own effects default to priority 1, and even an
// explicit priority-0 placement of theirs comes later in the list and so wins
// the tie in turn.
#let _with-base-placement(placement, effects) = {
  let effects = if type(effects) == dictionary {
    if effects.len() == 0 { () } else { (effects,) }
  } else {
    effects
  }
  ((effect: placement, subslides: "1-", priority: 0),) + effects
}

/// `#animate` starting from covered rather than shown, so effects say when
/// `body` *appears* instead of when it disappears. See `animate` for
/// everything else.
///
/// -> content
#let animate-hidden(body, effects: (), ..args) = animate(
  body,
  effects: _with-base-placement("cover", effects),
  ..args,
)


/// `#animate` starting from removed rather than shown. Like `animate-hidden`,
/// except the subslides where `body` is absent reserve no space at all, the way
/// `only` differs from `uncover`. See `animate` for everything else.
///
/// -> content
#let animate-removed(body, effects: (), ..args) = animate(
  body,
  effects: _with-base-placement("remove", effects),
  ..args,
)
